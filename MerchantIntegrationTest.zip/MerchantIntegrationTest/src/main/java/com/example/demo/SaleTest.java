package com.example.demo;

import com.fiserv.fdc.FDConnectUtils;
import com.fiserv.fdc.sale.model.FDConnectSaleRequest;
import com.fiserv.fdc.sale.model.FDConnectSaleResponse;
import com.fiserv.fdc.sale.model.ProductDataBean;

public class SaleTest {

	public static void main(String[] args) {

		
		/*FDConnectSaleRequest request = new FDConnectSaleRequest("470000000332252","CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=","9T4hd3Nx0b0sMgYuyWLCTg==","https://www.test.fdmerchantservices.com/FirstPayL2Services/getToken",
				"10","INR","TRA123456","sale","Prashanth","Mandarapu","Kumar","9769970828","Prashanth@gmail.com","https://merchantresposneurl");
		
		
		FDConnectSaleResponse resp = FDConnectUtils.saleTxn(request);
		
		System.out.println(" SessionTokenId : "+resp.getSessionTokenId());
		System.out.println(" ErrorCode : "+resp.getErrorCode());
		System.out.println(" ErrorMessage : "+resp.getErrorMessage());*/
		
		FDConnectSaleRequest request = new FDConnectSaleRequest();
				
		request.setMerchantId("470000000332252");
		request.setKey("CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=");
		request.setIv("9T4hd3Nx0b0sMgYuyWLCTg==");
		request.setResultURL("https://www.merchantreturnurl");
		request.setAmount("10");
		request.setCurrencyCode("INR");
		request.setMerchantTxnId("QFDE");
		request.setTransactionType("sale");
		request.setCustomerId("CUST1234");
		request.setFirstName("Prashanth");
		request.setLastName("Mandarapu");
		request.setMiddleName("Kumar");
		request.setSuffix("Mr");
		request.setMobileNo("9769970828");
		request.setEmailId("Prashanth@gmail.com");
		
		request.setBillStreet1("billStre'et1address");
		request.setBillStree2("billStree2");
		request.setBillState("billState");
		request.setBillCity("billCity");
		request.setBillState("billState");
		request.setBillZipcode("123456789");
		
		request.setShipStreet1("shipStreet1");
		request.setShipStree2("shipStree2");
		request.setShipCity("shipCity");
		request.setShipState("shipState");
		request.setShipZipcode("123456789");
		
		
		ProductDataBean bean = new ProductDataBean();
		
		bean.setProductId("Prod1");
		bean.setProductDescription("productDescription");
		bean.setQuantity("1");
		bean.setPrice("10");
		bean.setTxnAmount("10");
		bean.setShippingFee("0");
		bean.setDiscountPrice("0");
		
		request.setProductData(bean);
		
		request.setCardNumber("123234234234234");
		request.setExpMonth("01");
		request.setExpYear("21");
		request.setcVV("123");
		request.setNameOnCard("nameOnCard");
		
		request.setApiURL("https://www.test.fdmerchantservices.com/FirstPayL2Services/getToken");
		
		FDConnectSaleResponse resp = FDConnectUtils.saleTxn(request);
		
		System.out.println("resp SessionTokenId : "+resp.getSessionTokenId());
		System.out.println("resp ErrorCode : "+resp.getErrorCode());
		System.out.println("resp ErrorMessage : "+resp.getErrorMessage());
		
		
		
	}

}
