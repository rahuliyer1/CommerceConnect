package com.example.demo;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.servlet.http.HttpServletRequest;
import java.security.cert.CertificateException;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import sun.misc.BASE64Encoder;

import com.fiserv.fdc.FDConnectUtils;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryRequest;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryResponse;
import com.fiserv.fdc.refund.model.FDConnectRefundRequest;
import com.fiserv.fdc.refund.model.FDConnectRefundResponse;
import com.fiserv.fdc.response.model.FDConnectDecryptRequest;
import com.fiserv.fdc.response.model.FDConnectDecryptResponse;
import com.fiserv.fdc.sale.model.FDConnectSaleRequest;
import com.fiserv.fdc.sale.model.FDConnectSaleResponse;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;


@Controller
public class TestController {

	// DR_1 URL
	//	String fdcurl = "http://10.95.140.93:8080/FDConnectL3Services/";
	//	String urlPay = "http://10.95.140.93:8080/Pay";

	// DR_2 URL
	//	String fdcurl = "http://10.95.140.94:8080/FDConnectL3Services/";
	//	String urlPay = "http://10.95.140.94:8080/Pay";

	// String fdcurl = "https://ljpvwb1000:8443/FDConnectL3Services/";
	// String urlPay = "https://ljpvwb1000:8443/Pay";

	// DC_1 URL
	//	String fdcurl = "http://10.95.12.98:8080/FDConnectL3Services/";
	//	String urlPay = "http://10.95.12.98:8080/Pay";

	// DC_2 URL
	//	String fdcurl = "http://10.95.12.99:8080/FDConnectL3Services/";
	//	String urlPay = "http://10.95.12.99:8080/Pay";

	private static final Pattern MERCHANT_ID_PATTERN = Pattern.compile("merchantId=(\\d*)&");
	private static final Pattern FP_TXN_ID_PATTERN = Pattern.compile("fpTxnId=(\\d*)");
	private static final Pattern ENC_DATA_PATTERN = Pattern.compile("encData=(.*?)&fpTxnId");

	private static final String SERVERURL_TEST = "https://test.fdconnect.com";
	private static final String SERVERURL = "https://www.fdconnect.com";

	String fdcurl = "https://lipvwb1005:8443/FDConnectL3Services/";
	String urlPay = "https://lipvwb1005:8443/Pay";

	/*
	 * static { System.out.println("Static ...");
	 * System.setProperty("https.protocols", "TLSv1.2");
	 * System.setProperty("https.proxyHost", "10.95.3.88");
	 * System.setProperty("https.proxyPort", "8080"); }
	 */

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getCheckOutPage(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + "getCheckOutPage");
		ModelAndView modelAndView = new ModelAndView("mfirstpage");
		return modelAndView;
	}

	@RequestMapping(value = "/inquiry", method = RequestMethod.GET)
	public ModelAndView inquiryPage(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + " -- inquiry");
		ModelAndView modelAndView = new ModelAndView("inquiry");
		return modelAndView;
	}

	@RequestMapping(value = "/refund", method = RequestMethod.GET)
	public ModelAndView refundPage(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + "refund");
		ModelAndView modelAndView = new ModelAndView("refund");
		return modelAndView;
	}


	@RequestMapping(value = "/secure3dsMethod", method = RequestMethod.POST)
	public String secure3dsMethod(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + "secure3dsMethod");
		System.out.println("In 3ds Secure Method");
		if(httpServletRequest != null ){
			Map<String, String[]> param = httpServletRequest.getParameterMap();

			Set<String> keys = param.keySet();
			for(String key: keys){
				System.out.println("KEY --"+key);
				String[] values = param.get(key);

				if(values != null && values.length != 0){
					for (int i=0;i<values.length;i++)
						System.out.println("Value --"+values[i]);
				}
			}



		}

		return "secure3dsMethodGET";
	}

	@RequestMapping(value = "/secure3dsMethodG", method = RequestMethod.GET)
	public void secure3dsMethodGET(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + "secure3dsMethod");
		System.out.println("In 3ds Secure Method GET");

		//return "secure3dsMethodGET";
	}

	@RequestMapping(value = "/inquiryTxn", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public @ResponseBody String inquiryTxn(@RequestBody String requestStr) {

		String inquiryURL = null;
		if(SERVERURL.contains("test")){
			inquiryURL = SERVERURL+"/FirstPayL2Services/getTxnInquiryDetail";
		}else{
			inquiryURL = SERVERURL+"/FDConnectL3Services/getTxnInquiryDetail";
		}

		System.out.println(new Date() + " -- In inquiryTxn " + requestStr);
		Gson gson = new Gson();
		JsonObject jsonObject = gson.fromJson(requestStr, JsonObject.class);

		FDConnectInquiryRequest request = new FDConnectInquiryRequest();
		request.setMerchantId(jsonObject.get("storeId").getAsString());
		request.setApiURL(inquiryURL);

		request.setIv(jsonObject.get("iv").getAsString());
		request.setKey(jsonObject.get("key").getAsString());

		//request.setFpTransactionId(jsonObject.get("fpTxnId").getAsString());
		request.setMerchantTxnId(jsonObject.get("mrctTxnId").getAsString());

		FDConnectInquiryResponse inquiryResponse = FDConnectUtils.inquiryTxn(request);

		String jsonResp = gson.toJson(inquiryResponse);

		System.out.println("Inquiry jsonResp-->" + jsonResp);
		return jsonResp;
	}




	@RequestMapping("/inquiryTransaction")
	public String inquiryTransaction() {

		Gson gson = new Gson();
		//JsonObject jsonObject = gson.fromJson(requestStr, JsonObject.class);

		FDConnectInquiryRequest request = new FDConnectInquiryRequest();
		request.setApiURL("https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail");

		/*request.setMerchantId("470000087032227");
		request.setIv("1ExNy2VGE+lOEy7Ql8ReQg==");
		request.setKey("WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=");*/

		request.setMerchantId("470000087032227");
		request.setIv("nUKrqNOODiNlbVbwxRBuLQ==");
		request.setKey("LB+uy7kvkGk/D4fa/nSVg2fPB6+XyBv63WU19MSdABg=");

		//request.setFpTransactionId(jsonObject.get("fpTxnId").getAsString());
		request.setMerchantTxnId("IN9000-0000-89080");

		FDConnectInquiryResponse inquiryResponse = FDConnectUtils.inquiryTxn(request);

		String jsonResp = gson.toJson(inquiryResponse);

		System.out.println("jsonResp-->" + jsonResp);
		return jsonResp;
	}

	@RequestMapping(value = "/refundTxn", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public @ResponseBody String refundTransaction(@RequestBody String requestStr) {

		String refundURL = null;
		if(SERVERURL.contains("test")){
			refundURL = SERVERURL+"/FirstPayL2Services/refundTxnDetail";
		}else{
			refundURL = SERVERURL+"/FDConnectL3Services/refundTxnDetail";
		}

		System.out.println(new Date() + "-- In refundTxn " + requestStr);
		Gson gson = new Gson();
		JsonObject jsonObject = gson.fromJson(requestStr, JsonObject.class);

		FDConnectRefundRequest firstPayRefundRequest = new FDConnectRefundRequest();
		firstPayRefundRequest.setMerchantId(jsonObject.get("storeId").getAsString());
		firstPayRefundRequest.setApiURL(refundURL);

		firstPayRefundRequest.setIv(jsonObject.get("iv").getAsString());
		firstPayRefundRequest.setKey(jsonObject.get("key").getAsString());

		firstPayRefundRequest.setFpTransactionId(jsonObject.get("fpTxnId").getAsString());
		firstPayRefundRequest.setMerchantTxnId(jsonObject.get("mrctTxnId").getAsString());
		firstPayRefundRequest.setRefundAmount(jsonObject.get("refundAmount").getAsString());

		FDConnectRefundResponse resp = FDConnectUtils.refundTxn(firstPayRefundRequest);


		System.out.println(new Gson().toJson(resp));

		String jsonResp = gson.toJson(resp);

		System.out.println(" Return jsonResp-->" + jsonResp);
		return jsonResp;


		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";
		request.setFpTransactionId("2021032322423196");
		request.setMerchantTxnId("IN9000-0000-95966");
		request.setRefundAmount("40188.98");

		request.setMerchantId("470000015753000");
		request.setApiURL("https://www.fdconnect.com/FDConnectL3Services/refundTxnDetail");
		//request.setApiURL("https://www.test.fdmerchantservices.com/FirstPayL2Services/refundTxnDetail");
		request.setFpTransactionId("2021032322423196");
		request.setMerchantTxnId("IN9000-0000-95966");

		request.setKey("owB88nuLZcoXozguTtgp/iu/zcolwMtdUqBAnThmzV8=");
		request.setIv("2D50rJ4K2HmhVoZbmlNq5g==");

		request.setRefundAmount("1.28");*/
	}



	@RequestMapping(value = "/getTokenMrct", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public @ResponseBody String getToken(@RequestBody String requestStr) {

		System.out.println(new Date() + "In getTokenMrct " + requestStr);
		Gson gson = new Gson();

		JsonObject jsonObject = gson.fromJson(requestStr, JsonObject.class);


		FDConnectSaleRequest request = new FDConnectSaleRequest();

		String serverURL = "https://www.fdconnect.com"; //jsonObject.get("serverURL").getAsString();
		//	String serverURL = "https://test.fdconnect.com"; //jsonObject.get("serverURL").getAsString();
		if(serverURL.contains("test")){
			serverURL = SERVERURL_TEST;
		}else{
			serverURL = SERVERURL;
		}
		
		String resultURL = "http://localhost:9090/MerchantTest/getMerchantResponse";
		//String resultURL = "https://www.fdmerchantservices.com/MerchantTest/getMerchantResponse";
		//jsonObject.get("resultURL").getAsString();
		request.setMerchantId(jsonObject.get("storeId").getAsString());
		
		/*if(resultURL.contains("www.fdmerchantservices.com")){
			System.setProperty("https.proxyHost", "10.95.3.88"); 
			System.setProperty("https.proxyPort", "8080");
		}*/



		request.setKey(jsonObject.get("key").getAsString());
		request.setIv(jsonObject.get("iv").getAsString());
		// request.setResultURL("http://localhost:9090/MerchantTest/getMerchantResponse");
		request.setResultURL(resultURL);
		/*request.setIntegrationType(INTEGRATION_TYPE.MERCHANT_PAYMENT_MODE_INTEGRATION);
		request.setPaymentMethodType("UPI");
		request.setvPAId("9819424234@apl");*/

		request.setAmount(jsonObject.get("amountGetToken").getAsString());
		//request.setCurrencyCode("AUD");  //jsonObject.get("currencyCodeGetToken").getAsString()
		request.setCurrencyCode(jsonObject.get("currencyCodeGetToken").getAsString());
		request.setMerchantTxnId(jsonObject.get("clientTransactionIdGetToken").getAsString());
		request.setTransactionType("sale");

		request.setMobileNo("9819424234");
		request.setEmailId("rsi610@gmail.com");
		request.setUdf2("CashFree Solutions");

		//serverURL = "https://10.95.12.99:8443";
		String apiURL = null;
		if (serverURL.equalsIgnoreCase("https://test.fdconnect.com")
				|| serverURL.equals("https://10.95.12.100:8443")) {
			apiURL = serverURL + "/FirstPayL2Services/getToken";
		} else {
			apiURL = serverURL + "/FDConnectL3Services/getToken";
		}

		request.setApiURL(apiURL);

		System.out.println("serverURL-->" + request.getApiURL());

		FDConnectSaleResponse resp = FDConnectUtils.saleTxn(request);

		System.out.println("resp SessionTokenId : " + resp.getSessionTokenId());
		System.out.println("resp ErrorCode : " + resp.getErrorCode());
		System.out.println("resp ErrorMessage : " + resp.getErrorMessage());
		System.out.println("gson.toJson(resp) : " + gson.toJson(resp));

		JsonObject jsonObject2 = new JsonObject();

		jsonObject2.addProperty("sessionTokenId", resp.getSessionTokenId());

		if (serverURL.equals("https://test.fdconnect.com")
				|| serverURL.equals("https://10.95.12.100:8443")) {
			jsonObject2.addProperty("url", serverURL + "/Pay/");
		} else {
			jsonObject2.addProperty("url", serverURL + "/Pay/");
		}

		return jsonObject2.toString();
	}

	@RequestMapping(value = "/getMerchantResponse", method = RequestMethod.POST)
	public ModelAndView getMerchantResponse(HttpServletRequest request) {

		System.out.println("Decrypt getMerchantResponse---->" + request);

		String fpTxnId = request.getParameter("fpTxnId");
		String merchantId = request.getParameter("merchantId");
		String encrypatData = request.getParameter("encData");

		/*
		 * System.setProperty("https.protocols", "TLSv1.2");
		 * System.setProperty("https.proxyHost", "10.95.3.88");
		 * System.setProperty("https.proxyPort", "8080");
		 * 
		 * System.setProperty("http.protocols", "TLSv1.2");
		 * System.setProperty("http.proxyHost", "10.95.3.88");
		 * System.setProperty("http.proxyPort", "8080");
		 */

		// FDConnectDecryptRequest fdConnectDecryptRequest = new
		// FDConnectDecryptRequest(merchantId,encrypatData,fpTxnId,"http://10.95.12.98:8080/FDConnectL3Services/decryptMerchantResponse");
		// FDConnectDecryptRequest fdConnectDecryptRequest = new
		// FDConnectDecryptRequest(merchantId,encrypatData,fpTxnId,"http://10.95.12.99:8080/FDConnectL3Services/decryptMerchantResponse");
		/*FDConnectDecryptRequest fdConnectDecryptRequest = 
				new FDConnectDecryptRequest(merchantId,encrypatData,fpTxnId,"https://test.fdconnect.com/FirstPayL2Services/decryptMerchantResponse");*/
		FDConnectDecryptRequest fdConnectDecryptRequest = 
				new FDConnectDecryptRequest(merchantId,encrypatData,fpTxnId,
						"https://www.fdconnect.com/FDConnectL3Services/decryptMerchantResponse");


		System.out.println("encrypatData :"+encrypatData);

		/*fdConnectDecryptRequest.setEncData(encrypatData);
		fdConnectDecryptRequest.setFpTxnId(fpTxnId);
		fdConnectDecryptRequest.setFpURL("https://www.fdconnect.com/FDConnectL3Services/decryptMerchantResponse");
		//fdConnectDecryptRequest.setFpURL("https://www.test.fdmerchantservices.com/FirstPayL2ServicesProd/decryptMerchantResponse");
		fdConnectDecryptRequest.setMerchantId(merchantId);*/

		FDConnectDecryptResponse resp = FDConnectUtils.decryptMsg(fdConnectDecryptRequest);

		System.out.println(resp.getErrorCode());
		System.out.println(resp.getErrorMessage());
		System.out.println(new Gson().toJson(resp));

		ModelAndView modelAndView = new ModelAndView("merchantSuccessPage");

		modelAndView.addObject("TransactionStatus", resp.getTransactionStatus());
		modelAndView.addObject("TransactionStatusCode", resp.getTransactionStatusCode());
		modelAndView.addObject("TransactionId", resp.getFpTransactionId());
		modelAndView.addObject("FinalResponse", new Gson().toJson(resp));
		return modelAndView;

	}



	@RequestMapping(value = "/getHPInit", method = RequestMethod.POST)
	public ModelAndView getHPInit(HttpServletRequest httpServletRequest) {

		System.out.println("in get hp init");

		String finalResp = null;
		try {

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };

			System.setProperty("https.proxyPort", "8080");
			System.setProperty("https.proxyHost", "10.95.3.88");
			System.setProperty("https.protocols", "TLSv1.2");
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			// URL obj = new URL("https://localhost:8443/FirstPayL2Services/getToken");
			// HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
			URL obj = new URL("http://localhost:8100/FirstPayL2Services/init");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");

			System.out.println("sessionoken---->" + httpServletRequest.getParameter("sessionToken"));

			con.setRequestProperty("sessionToken", httpServletRequest.getParameter("sessionToken"));

			String jsonString = "{\"configId\":\"" + httpServletRequest.getParameter("configId")
					+ "\",\"paymentMethodType\":\"" + httpServletRequest.getParameter("paymentMethodType") + "\"}";

			System.out.println("jsonString---->" + jsonString);

			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(jsonString);
			wr.flush();
			wr.close();
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}

			in.close();

			finalResp = response.toString();
			System.out.println(" Response from URL   : " + finalResp);

		}  catch (Exception e) {
			e.printStackTrace();
		}

		ModelAndView modelAndView = new ModelAndView("hostedpage");
		modelAndView.addObject("sessionToken", httpServletRequest.getParameter("sessionToken"));

		return modelAndView;
	}

	@RequestMapping(value = "/testJSON", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public @ResponseBody String testJSON(@RequestBody String requestStr) {

		System.out.println("In testJSON " + requestStr);
		JsonObject jsonObject = new JsonObject();
		try {
			Gson gson = new Gson();

			jsonObject = gson.fromJson(requestStr, JsonObject.class);

		} catch (JsonSyntaxException e) {
			System.out.println("in exception---->");
			jsonObject.addProperty("Exception", "Bad Request");
			e.printStackTrace();
		}

		return jsonObject.toString();
	}

	@RequestMapping(value = "/rppayment", method = RequestMethod.GET)
	public ModelAndView rppayment(HttpServletRequest servletRequest) throws Exception {

		ModelAndView modelAndView = new ModelAndView("submitRazorPay");

		String data = "{\"amount\":" + "\"1000\""
				+ ",\"currency\":\"INR\",   \"receipt\":\"rcp1342341213\", \"payment_capture\":\"1\",  \"notes\":{}  }";
		System.out.println("Input data " + data);

		System.out.println(System.getProperty("java.version"));

		String resp = sendDataRazorPay("https://api.razorpay.com/v1/orders", data, false, "acc_BtV471xgBWayPS");
		System.out.println("Resp--->" + resp);

		Gson gson = new Gson();
		JsonObject jsonObject = gson.fromJson(resp, JsonObject.class);

		String dataResp = jsonObject.get("id").toString().trim();

		System.out.println("dataResp-->" + dataResp.replaceAll("\"", ""));

		modelAndView.addObject("amount", "1000");
		modelAndView.addObject("orderId", dataResp.replaceAll("\"", "").trim());
		modelAndView.addObject("url", "http://localhost:9090/MerchantTest/rpresponse?pgTxnNo=1234563&id=");
		// servletRequest.setAttribute("url",
		// "http://10.95.12.100:8080/MerchantTest/rpresponse?pgTxnNo=1234563&id=");

		return modelAndView;
	}

	public static String sendDataRazorPay(String urlString, String text2, boolean state, String acct_id)
			throws Exception {
		String output = "";
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs, String authType) {
			}

			@Override
			public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub

			}

			@Override
			public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
					throws CertificateException {
				// TODO Auto-generated method stub

			}
		} };
		String resp = null;
		// Install the all-trusting trust manager
		SSLContext sc = SSLContext.getInstance("SSL");
		sc = SSLContext.getInstance("TLSv1.2");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		// Install the all-trusting host verifier
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		URL url = new URL("https://api.razorpay.com/v1/orders");
		System.setProperty("https.proxyHost", "INBOM1Proxy.1dc.com");
		System.setProperty("https.proxyPort", "3128");
		System.setProperty("http.proxyHost", "INBOM1Proxy.1dc.com");
		System.setProperty("http.proxyPort", "3128");

		System.setProperty("https.proxyHost", "10.95.3.88");
		System.setProperty("https.proxyPort", "8080");
		System.setProperty("http.proxyHost", "10.95.3.88");
		System.setProperty("http.proxyPort", "8080");

		System.setProperty("https.protocols", "TLSv1.2");
		HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
		httpURLConnection.setRequestMethod("POST");
		httpURLConnection.setRequestProperty("Content-Type", "application/json");
		httpURLConnection.setRequestProperty("https.proxyHost", "INBOM1Proxy.1dc.com");
		httpURLConnection.setRequestProperty("https.proxyPort", "3128");
		httpURLConnection.setRequestProperty("https.proxyHost", "10.95.3.88");
		httpURLConnection.setRequestProperty("https.proxyPort", "8080");
		httpURLConnection.setRequestProperty("https.protocols", "TLSv1.2");
		String authString = "rzp_test_gtk1sllUceDB5s" + ":" + "FuuWyzTFB0M54RRnPkd6RVt9";
		BASE64Encoder enc = new sun.misc.BASE64Encoder();
		String encoded = new String(enc.encode(authString.getBytes()));
		System.out.println(encoded);
		httpURLConnection.setRequestProperty("Authorization", "Basic " + encoded);
		// httpURLConnection.setRequestProperty("Authorization", "Basic
		// cnpwX2xpdmVfcGFydG5lcl9CdFVpOFFKVVc4TFRLQzpHVmNsblBiRUVqeTB0RXNBbjlRQ1dTb3o=");
		httpURLConnection.setRequestProperty("X-Razorpay-Account", "acc_CUv4CVKZnRLhAQ");
		httpURLConnection.setDoOutput(true);
		httpURLConnection.setDoInput(true);
		DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
		dataOutputStream.write(text2.getBytes());
		dataOutputStream.flush();
		dataOutputStream.close();
		BufferedReader in = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
		StringBuffer response = new StringBuffer();
		while ((output = in.readLine()) != null) {
			response.append(output);
		}
		int responseCode = httpURLConnection.getResponseCode();
		String responseObj = response.toString();
		if (responseCode == HttpURLConnection.HTTP_OK) {
			System.out.println("Resp " + responseObj);
		}
		in.close();

		return responseObj;
	}

	@RequestMapping(value = "/razorPayResponse", method = RequestMethod.GET)
	public String razorPayResponse(HttpServletRequest servletRequest) {

		String A = servletRequest.getParameter("A");
		System.out.println("razorPayResponse" + A);

		return null;

	}

	@RequestMapping(value = "/testreact", method = RequestMethod.GET)
	public ModelAndView testReact(HttpServletRequest httpServletRequest) {
		System.out.println("indexxxxxxxx");
		ModelAndView modelAndView = new ModelAndView("index");
		return modelAndView;
	}

	@RequestMapping(value = "/iframetest", method = RequestMethod.GET)
	public ModelAndView iframetest(HttpServletRequest httpServletRequest) {
		System.out.println(new Date() + "iframetest");
		ModelAndView modelAndView = new ModelAndView("iframetest");
		return modelAndView;
	}

	@RequestMapping(value = "/inquiryTxn")
	public String doInquiry(){

		String url = "https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail";
		//String url = "https://www.test.fdmerchantservices.com/FirstPayL2Services/getTxnInquiryDetail";
		/*String key= "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";
	String iv =  "9T4hd3Nx0b0sMgYuyWLCTg==";*/

		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/

		/*String key= "owB88nuLZcoXozguTtgp/iu/zcolwMtdUqBAnThmzV8=";
		String iv =  "2D50rJ4K2HmhVoZbmlNq5g==";
		String merchantId =  "470000015753000";*/
		String key= "B9BWR9vJd0TTaDeQR+zsiK4NThwR7Bsyym/KjbGXVXQ=";
		String iv =  "w2sTwr6vo2dKt0FCu2NaMw==";
		String merchantId =  "470000087058558";

		/*String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000000255972";*/
		//String pageId = "PageId2020011459880";


		FDConnectInquiryRequest request = new FDConnectInquiryRequest();

		request.setMerchantId(merchantId);
		request.setApiURL(url);
		//request.setFpTransactionId("2020121044030435");
		request.setMerchantTxnId("11628821");

		request.setIv(iv);
		request.setKey(key);
		//request.setRefundAmount("1.02");

		FDConnectInquiryResponse resp = FDConnectUtils.inquiryTxn(request);
		Gson gson = new Gson();
		System.out.println("Resp : "+gson.toJson(resp));

		return gson.toJson(resp);


	}
	@RequestMapping(value = "/doRefund")
	public String doRefund(){

		String url = "https://www.fdconnect.com/FDConnectL3Services/refundTxnDetail";
		/*String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000000255972";*/

		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/
		//String pageId = "PageId2019120415869";

		/*request.setMerchantId("470000087032227");
		request.setIv("1ExNy2VGE+lOEy7Ql8ReQg==");
		request.setKey("WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=");*/

		String key= "LB+uy7kvkGk/D4fa/nSVg2fPB6+XyBv63WU19MSdABg=";
		String iv =  "nUKrqNOODiNlbVbwxRBuLQ==";
		String merchantId =  "470000087032227";

		FDConnectRefundRequest request = new FDConnectRefundRequest();

		request.setMerchantId(merchantId);
		request.setApiURL(url);
		/*request.setFpTransactionId("2021100455846010");
		request.setMerchantTxnId("h7lk7218rju");*/
		request.setFpTransactionId("2021073089522430");
		request.setMerchantTxnId("IN9000-0001-21921");
		request.setIv(iv);
		request.setKey(key);
		request.setRefundAmount("61990.00");

		FDConnectRefundResponse resp = FDConnectUtils.refundTxn(request);
		Gson gson = new Gson();
		System.out.println("Resp 111 : "+gson.toJson(resp));

		return gson.toJson(resp);


	}

	@RequestMapping(value = "/decryptTxn")
	public void doDecrypt(){
		String req_url ="https://www.fdconnect.com/FDConnectL3Services/redirectToMerchantUrl?merchantId=470000075938260&encData=vP5jCFPRIVhcCKJTLsAmCqUXkG8h0TkYWjShGAPDP7LZW8nTK7C5dbSFEm2mqcVfHtwOHS9B+anDghwyBGaBcE2pmrDwYfS68Vl/S1dUaHmcr4z5tx1S5rG49AnJZs0AdNmhd9gUWrxWfRzsjtKpnp3ITyeuj36Gpr1d7a2iyJsyK24GboJeylP6i4MQqmtXMp6HRjXvm7fiIyGMVGzQi0NkrOQsSp7Q0VIvWcrMAxioxIslcccvTulHtMVTN/PAw+x8NqyqhVT290aBOSXbJbuBo37KbZlYoN3WhjlUXiQJ/myh+gzPNHWN5EtabDwPaB1Aruq9f/MS/kGe3Hi1pOF25rgbJaPJgiFjYj2K25DR/j13w8Gty9bG6eWH3LC19XsriUA21cway0Gm8rBS9bV1jr4l2CNn/Pl18vfYf6SIJeasdAK4NhXPkKqIvaprJ9FRG6K2/GFOrBF01rHFs9lVGiYoTUVs+sa003Llecr8i4LGrVhwExfdnM0x4uR3HnHFNFQVUGxa8os8+WYBnXQMlL3+pGZCFBheqqKrS+SIUd5gcGlWLNliVX+I4q8aeAn0lmFcdCVa7tIZT7N//XHAshijVpiqxZphw0EMFHbfjD+K2evHLcbtakP3v4cBTvNnTEDIfaTNic4fF9u34xXS8gJaWRU4187vkmP8LNSJaeugT/1SCK2QVhQggXqIJlHzTNzokJRlqOGPlbRMh9hbYVTZr6XfuNQ85THFUY1z5q9ewvP8Y5vZkZ8o+Ukv4bwuJIAWr8OUsLEX3ikdFVzHdf1/5GN2rij4A6rsi0P5ULCMuiyBweKGBFqD7w3yyPZt/R4GuT2BjjNhWrJwIwrU8dDsPMpZ8fXg9ana12pqP+Dk91WZ3MchcGmKH5zPkFSGqGnqzH7AtmXRCids9Rn2HVyfFhvm0LVzARqBPHbtmh/0B4ipo+ErxAutsvDZ&fpTxnId=2021031537844754&resultURL=http://localhost:8181/host/getRequestParameter.jsp";
		String merchantId = null;
		String encData = null;
		String fpTxnId = null;
		Matcher merchantIdMatcher = MERCHANT_ID_PATTERN.matcher(req_url);
		Matcher fpTxnIdMatcher = FP_TXN_ID_PATTERN.matcher(req_url);
		Matcher encDataMatcher = ENC_DATA_PATTERN.matcher(req_url);

		if (merchantIdMatcher.find()) {
			merchantId = merchantIdMatcher.group(1);
		}

		if (fpTxnIdMatcher.find()) {
			fpTxnId = fpTxnIdMatcher.group(1);
		}

		if (encDataMatcher.find()) {
			encData = encDataMatcher.group(1);
		}

		System.out.println(" encData :"+encData);
		System.out.println(" fpTxnId :"+fpTxnId);
		System.out.println(" merchantId :"+merchantId);


		FDConnectDecryptRequest fdConnectDecryptRequest = 
				new FDConnectDecryptRequest(merchantId,encData,fpTxnId,"https://www.fdconnect.com/FDConnectL3Services/decryptMerchantResponse");


		System.out.println("encrypatData :"+encData);

		/*fdConnectDecryptRequest.setEncData(encrypatData);
		fdConnectDecryptRequest.setFpTxnId(fpTxnId);
		fdConnectDecryptRequest.setFpURL("https://www.fdconnect.com/FDConnectL3Services/decryptMerchantResponse");
		//fdConnectDecryptRequest.setFpURL("https://www.test.fdmerchantservices.com/FirstPayL2ServicesProd/decryptMerchantResponse");
		fdConnectDecryptRequest.setMerchantId(merchantId);*/

		FDConnectDecryptResponse resp = FDConnectUtils.decryptMsg(fdConnectDecryptRequest);

		System.out.println(resp.getErrorCode());
		System.out.println(resp.getErrorMessage());
		System.out.println(new Gson().toJson(resp));

	}


	@RequestMapping(value = "/bulkInquiryTxn")
	public String doBulkInquiry() throws IOException{

		String url = "https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail";
		/*String key= "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";
	String iv =  "9T4hd3Nx0b0sMgYuyWLCTg==";*/
		
		/*String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000000255972";
*/
		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/

		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/

		String key= "LB+uy7kvkGk/D4fa/nSVg2fPB6+XyBv63WU19MSdABg=";
		String iv =  "nUKrqNOODiNlbVbwxRBuLQ==";
		String merchantId =  "470000087032227";

		/*String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000087011099";*/
		//String pageId = "PageId2020011459880";


		FDConnectInquiryRequest request = new FDConnectInquiryRequest();

		List<String> orderIDs = readIPGRefundFileData();
		System.out.println("SIZE :"+orderIDs.size());
		for(String orderId : orderIDs){

			request.setMerchantId(merchantId);
			request.setApiURL(url);
			//request.setFpTransactionId("2020121044030435");
			request.setMerchantTxnId(orderId);
			request.setIv(iv);
			request.setKey(key);
			//request.setRefundAmount("1.02");

			FDConnectInquiryResponse resp = FDConnectUtils.inquiryTxn(request);
			Gson gson = new Gson();
			//resp.getSaleTxnDetail().getTransactionStatus()
			System.out.println("Resp : "+gson.toJson(resp));

		}
		return "COMPLETE";



	}

	public static List<String> readIPGRefundFileData() throws IOException
	{

		List<String> orderIDs = new ArrayList<String>();
		String  fileInput= "Inquiry_Tran.txt";
		BufferedReader arnReader = new BufferedReader(new FileReader(fileInput)); 
		String st; 
		while ((st = arnReader.readLine()) != null) {
			if(st!= null){

				String data = st.trim(); 


				orderIDs.add(data);
			}
		}
		return orderIDs;
	}



	@RequestMapping(value = "/inquiryTxnTest")
	public String doInquiryTest(){

		String url = "https://test.fdconnect.com/FirstPayL2Services/getTxnInquiryDetail";
		String key= "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";
		String iv =  "9T4hd3Nx0b0sMgYuyWLCTg==";
		String merchantId =  "470000000332260";
		//String pageId = "PageId2020011459880";


		FDConnectInquiryRequest request = new FDConnectInquiryRequest();

		request.setMerchantId(merchantId);
		request.setApiURL(url);
		//request.setFpTransactionId("2020121044030435");
		request.setMerchantTxnId("gdh53g5s26");

		request.setIv(iv);
		request.setKey(key);
		//request.setRefundAmount("1.02");

		FDConnectInquiryResponse resp = FDConnectUtils.inquiryTxn(request);
		Gson gson = new Gson();
		System.out.println("Resp : "+gson.toJson(resp));

		return gson.toJson(resp);


	}
	@RequestMapping(value = "/refundTxnTest")
	public String doRefundTest(){

		String url = "https://test.fdconnect.com/FirstPayL2Services/refundTxnDetail";

		String key= "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";
		String iv =  "9T4hd3Nx0b0sMgYuyWLCTg==";
		String merchantId =  "470000000332260";
		FDConnectRefundRequest request = new FDConnectRefundRequest();

		request.setMerchantId(merchantId);
		request.setApiURL(url);
		request.setFpTransactionId("2021052495083292");
		request.setMerchantTxnId("gdh53g5s26");
		request.setIv(iv);
		request.setKey(key);
		request.setRefundAmount("1");

		FDConnectRefundResponse resp = FDConnectUtils.refundTxn(request);
		Gson gson = new Gson();
		System.out.println("Resp 111 : "+gson.toJson(resp));

		return gson.toJson(resp);


	}

	@RequestMapping(value="/doMismatchInquiry", method = RequestMethod.GET)
	public String doMismatchInquiry(@RequestParam String merchantID, @RequestParam String merchantTransactionId) {

		
		String url = "https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail";
		String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000000255972";


		if("470000087032228".equals(merchantId)){
			key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
			iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		}
		if("470000087032227".equals(merchantId)){
			key= "LB+uy7kvkGk/D4fa/nSVg2fPB6+XyBv63WU19MSdABg=";
			iv =  "nUKrqNOODiNlbVbwxRBuLQ==";
		}
		/*String key= "CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=";
	String iv =  "9T4hd3Nx0b0sMgYuyWLCTg==";*/

		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/

		/*String key= "WtBd3KGxLZnKlMVMLeq+kRzXkEfDJqfCQa001H3DlRI=";
		String iv =  "1ExNy2VGE+lOEy7Ql8ReQg==";
		String merchantId =  "470000087032228";*/

		/*String key= "LB+uy7kvkGk/D4fa/nSVg2fPB6+XyBv63WU19MSdABg=";
		String iv =  "nUKrqNOODiNlbVbwxRBuLQ==";
		String merchantId =  "470000087032227";*/

		/*String key= "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
		String iv =  "dLZmkqqFBGmnJ2LtLIY0fA==";
		String merchantId =  "470000087011099";*/
		//String pageId = "PageId2020011459880";


		FDConnectInquiryRequest request = new FDConnectInquiryRequest();

		request.setMerchantId(merchantId);
		request.setApiURL(url);
		//request.setFpTransactionId("2020121044030435");
		request.setMerchantTxnId(merchantTransactionId);
		request.setIv(iv);
		request.setKey(key);
		//request.setRefundAmount("1.02");

		FDConnectInquiryResponse resp = FDConnectUtils.inquiryTxn(request);
		Gson gson = new Gson();
		System.out.println("Resp : "+gson.toJson(resp));

		return "COMPLETE";


	}


}
