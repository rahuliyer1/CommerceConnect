package com.example.demo;

import com.fiserv.fdc.FDConnectUtils;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryRequest;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryResponse;
import com.fiserv.fdc.inquiry.model.FpInquiryTxnDetailBean;
import com.google.gson.Gson;

public class InquiryTest {
	public static void main(String[] args) {

		// FDConnectInquiryRequest firstPayInquiryRequest = new
		// FDConnectInquiryRequest("470000000332252","CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=","9T4hd3Nx0b0sMgYuyWLCTg==","http://localhost:8100/FirstPayL2Services/getTxnInquiryDetail","123456","2019092518359898");
		FDConnectInquiryRequest firstPayInquiryRequest = new FDConnectInquiryRequest();

		firstPayInquiryRequest.setMerchantId("470000050712620");
		firstPayInquiryRequest.setMerchantTxnId("xxb1dkpl988");
		firstPayInquiryRequest.setFpTransactionId("2019121626440594");
		firstPayInquiryRequest.setApiURL("http://10.95.12.99:8080/FDConnectL3Services/getTxnInquiryDetail");
		firstPayInquiryRequest.setKey("ZXBNPTSrKRvdvc4KKAi4PwBnc4jr0LBeMRxVERXPu50=");
		firstPayInquiryRequest.setIv("kIebKyq41m0/a++SIfW7CA==");

		FDConnectInquiryResponse resp = FDConnectUtils.inquiryTxn(firstPayInquiryRequest);

		System.out.println(resp.getErrorCode());
		System.out.println(resp.getErrorMessage());
		//System.out.println(new Gson().toJson(resp));
	}
}
