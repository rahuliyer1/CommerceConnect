package com.example.demo;

import com.fiserv.fdc.FDConnectUtils;
import com.fiserv.fdc.refund.model.FDConnectRefundRequest;
import com.fiserv.fdc.refund.model.FDConnectRefundResponse;
import com.google.gson.Gson;

public class RefundTest {

	public static void main(String[] args) {

		FDConnectRefundRequest firstPayRefundRequest = new FDConnectRefundRequest();
		
		firstPayRefundRequest.setMerchantId("470000000332252");
		firstPayRefundRequest.setMerchantTxnId("Q0PTRA235672");
		firstPayRefundRequest.setFpTransactionId("2019111933869299");
		firstPayRefundRequest.setApiURL("https://10.95.12.98:8443/FDConnectL3Services/refundTxnDetail");
		firstPayRefundRequest.setKey("CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=");
		firstPayRefundRequest.setIv("9T4hd3Nx0b0sMgYuyWLCTg==");
		firstPayRefundRequest.setRefundAmount("1");
			
		FDConnectRefundResponse resp = FDConnectUtils.refundTxn(firstPayRefundRequest);
		
		System.out.println(resp.getAmount());
		System.out.println(resp.getFpRefundTransactionId());
		System.out.println(resp.getFpTransactionId());
		System.out.println(resp.getPaymentType());
		System.out.println(resp.getTransactionStatus());
		
		//System.out.println(new Gson().toJson(resp));
		
	}

}
