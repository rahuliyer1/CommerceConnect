function submitFormFP(){
	var url = "http://localhost:8100/FirstPayL2Services/getHPInit";
	//$(".loaderClass").show();
	//$("#checkoutForm").hide();
	document.getElementById("fpbtn").disabled = true;
	document.getElementById("checkoutForm").setAttribute("action", url);
	document.getElementById("checkoutForm").setAttribute("method", "post");
	document.forms['checkoutForm'].submit();	
}